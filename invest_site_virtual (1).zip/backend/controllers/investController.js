const Investment = require('../models/Investment');

exports.createInvestment = async (req, res) => {
  const { userId, product, amount } = req.body;
  const investment = new Investment({ userId, product, amount });
  await investment.save();
  res.status(201).json({ message: 'Investimento registrado' });
};
