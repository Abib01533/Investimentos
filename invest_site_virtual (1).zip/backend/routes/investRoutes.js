const express = require('express');
const router = express.Router();
const { createInvestment } = require('../controllers/investController');

router.post('/', createInvestment);

module.exports = router;
