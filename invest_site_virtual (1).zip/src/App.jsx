import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const products = [
  {
    id: 1,
    name: "Curso de Criptomoedas",
    description: "Invista em educação digital e aumente seus lucros.",
    minInvest: 20,
    retorno: "+30% ao mês",
  },
  {
    id: 2,
    name: "Pacote de E-books Premium",
    description: "Receba e-books exclusivos e ganhe com a revenda.",
    minInvest: 15,
    retorno: "+25% ao mês",
  },
  {
    id: 3,
    name: "Software de Automação",
    description: "Invista em tecnologia e receba dividendos mensais.",
    minInvest: 50,
    retorno: "+40% ao mês",
  },
];

export default function InvestSite() {
  const [selected, setSelected] = useState(null);
  const [amount, setAmount] = useState(0);
  const [message, setMessage] = useState("");
  const [token, setToken] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleRegister = async () => {
    const res = await fetch("http://localhost:5000/api/users/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    alert(data.message);
  };

  const handleLogin = async () => {
    const res = await fetch("http://localhost:5000/api/users/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (data.token) {
      setToken(data.token);
      alert("Login bem-sucedido!");
    }
  };

  const handleInvest = async () => {
    if (!selected || amount < selected.minInvest) {
      setMessage("Valor mínimo de investimento não atingido.");
      return;
    }
    const res = await fetch("http://localhost:5000/api/investments", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        userId: "me", // ajustável no backend
        product: selected.name,
        amount: Number(amount),
      }),
    });
    const data = await res.json();
    setMessage(data.message);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <h1 className="text-3xl font-bold text-center mb-8">Plataforma de Investimentos</h1>

      {!token ? (
        <div className="max-w-md mx-auto bg-white rounded p-4 shadow mb-6">
          <h2 className="text-xl font-semibold mb-2">Login / Registro</h2>
          <Input placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <Input type="password" placeholder="Senha" className="mt-2" value={password} onChange={(e) => setPassword(e.target.value)} />
          <div className="flex gap-2 mt-4">
            <Button onClick={handleLogin}>Login</Button>
            <Button onClick={handleRegister}>Registrar</Button>
          </div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {products.map((product) => (
              <Card
                key={product.id}
                className={`cursor-pointer hover:shadow-xl transition-all ${
                  selected?.id === product.id ? "border-blue-500 border-2" : ""
                }`}
                onClick={() => setSelected(product)}
              >
                <CardContent>
                  <h2 className="text-xl font-semibold">{product.name}</h2>
                  <p className="text-sm text-gray-600">{product.description}</p>
                  <p className="mt-2 text-green-600 font-bold">{product.retorno}</p>
                  <p className="text-xs text-gray-500">Mínimo: ${product.minInvest}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="bg-white p-4 rounded shadow max-w-md mx-auto">
            <h3 className="font-semibold mb-2">Valor a Investir</h3>
            <Input
              type="number"
              placeholder="Ex: 50"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <Button className="mt-4 w-full" onClick={handleInvest}>
              Confirmar Investimento
            </Button>
            {message && <p className="mt-2 text-center text-sm">{message}</p>}
          </div>
        </>
      )}
    </div>
  );
}
