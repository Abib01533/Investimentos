document.getElementById("formCadastro").addEventListener("submit", function(e) {
  e.preventDefault();

  const nome = document.getElementById("nome").value;
  const email = document.getElementById("email").value;
  const valor = document.getElementById("valor").value;

  if (!nome || !email || !valor) {
    alert("Por favor, preencha todos os campos.");
    return;
  }

  const conta = {
    nome,
    email,
    valor: parseFloat(valor)
  };

  localStorage.setItem("contaInvestimento", JSON.stringify(conta));

  document.getElementById("mensagem").innerText = "Conta criada com sucesso!";
  document.getElementById("formCadastro").reset();
});
